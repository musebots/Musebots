function Voice(){
	this.ambit;
}

function Instrument(){
	this.range;
	this.polyphony;
	this.channel;
}